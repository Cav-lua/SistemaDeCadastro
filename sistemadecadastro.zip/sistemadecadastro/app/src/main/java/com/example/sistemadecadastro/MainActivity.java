package com.example.sistemadecadastro;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Registro> registros;
    private ArrayAdapter<Registro> adapter;

    private EditText edNome, edEndereco, edTelefone;
    private ListView listViewRegistros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registros = new ArrayList<>();
        edNome = findViewById(R.id.edNome);
        edEndereco = findViewById(R.id.edEndereco);
        edTelefone = findViewById(R.id.edTelefone);
        listViewRegistros = findViewById(R.id.listViewRegistros);

        Button btnCadastrar = findViewById(R.id.btnCadastrar);
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = edNome.getText().toString();
                String endereco = edEndereco.getText().toString();
                String telefone = edTelefone.getText().toString();

                if (!nome.isEmpty() && !endereco.isEmpty() && !telefone.isEmpty()) {
                    Registro registro = new Registro(nome, endereco, telefone);
                    registros.add(registro);
                    updateListView();
                    clearFields();
                } else {
                    showMessage("Todos os campos devem ser preenchidos.");
                }
            }
        });
    }

    private void updateListView() {
        if (adapter == null) {
            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, registros);
            listViewRegistros.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
    }

    private void clearFields() {
        edNome.setText("");
        edEndereco.setText("");
        edTelefone.setText("");
    }

    private void showMessage(String msg) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle("Aviso");
        dialog.setMessage(msg);
        dialog.setNeutralButton("OK", null);
        dialog.show();
    }
}
